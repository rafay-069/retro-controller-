// Retro-Go target: rafay-console (custom ESP32-S3 handheld, Rev 1 PCB)
// Copy this folder to components/retro-go/targets/rafay-console in the
// retro-go source tree, then build with:  ./rg_tool.py --target=rafay-console
// Every GPIO below matches pcb/PINOUT.md exactly. Do not edit one without
// the other.

// Target definition
#define RG_TARGET_NAME              "RAFAY CONSOLE"

// Storage (microSD slot on the screen module, shares the LCD SPI bus)
#define RG_STORAGE_ROOT             "/sd"
#define RG_STORAGE_SDSPI_HOST       SPI2_HOST
#define RG_STORAGE_SDSPI_SPEED      SDMMC_FREQ_DEFAULT

// Audio (external I2S DAC/amp = MAX98357A; ESP32-S3 has no internal DAC)
#define RG_AUDIO_USE_INT_DAC        0   // 0 = Disable
#define RG_AUDIO_USE_EXT_DAC        1   // 0 = Disable, 1 = Enable

// Video (2.8" ILI9341 module, native portrait glass mounted rotated = 320x240)
#define RG_SCREEN_DRIVER            0   // 0 = ILI9341/ST7789
#define RG_SCREEN_HOST              SPI2_HOST
#define RG_SCREEN_SPEED             SPI_MASTER_FREQ_40M
#define RG_SCREEN_BACKLIGHT         1
#define RG_SCREEN_WIDTH             320
#define RG_SCREEN_HEIGHT            240
#define RG_SCREEN_ROTATE            0
#define RG_SCREEN_VISIBLE_AREA      {0, 0, 0, 0}
#define RG_SCREEN_SAFE_AREA         {0, 0, 0, 0}
// Init sequence: the ODROID-GO ILI9341 reference sequence (same driver and
// controller). BRING-UP NOTE: MADCTL is command 0x36 below (0xA8). If the
// picture comes up rotated or mirrored on the real module, change ONLY that
// byte: try 0xE8, 0x28, or 0x68 (the four rotations, BGR kept) until the
// launcher reads correctly. This is a one-line, expected bring-up tweak.
#define RG_SCREEN_INIT()                                                                                         \
    ILI9341_CMD(0xCF, 0x00, 0xc3, 0x30);                                                                         \
    ILI9341_CMD(0xED, 0x64, 0x03, 0x12, 0x81);                                                                   \
    ILI9341_CMD(0xE8, 0x85, 0x00, 0x78);                                                                         \
    ILI9341_CMD(0xCB, 0x39, 0x2c, 0x00, 0x34, 0x02);                                                             \
    ILI9341_CMD(0xF7, 0x20);                                                                                     \
    ILI9341_CMD(0xEA, 0x00, 0x00);                                                                               \
    ILI9341_CMD(0xC0, 0x1B);                 /* Power control   //VRH[5:0] */                                    \
    ILI9341_CMD(0xC1, 0x12);                 /* Power control   //SAP[2:0];BT[3:0] */                            \
    ILI9341_CMD(0xC5, 0x32, 0x3C);           /* VCM control */                                                   \
    ILI9341_CMD(0xC7, 0x91);                 /* VCM control2 */                                                  \
    ILI9341_CMD(0x36, 0xA8);                 /* Memory Access Control (MY|MV|BGR) */                             \
    ILI9341_CMD(0xB1, 0x00, 0x10);           /* Frame Rate Control (1B=70, 1F=61, 10=119) */                     \
    ILI9341_CMD(0xB6, 0x0A, 0xA2);           /* Display Function Control */                                      \
    ILI9341_CMD(0xF6, 0x01, 0x30);                                                                               \
    ILI9341_CMD(0xF2, 0x00);                 /* 3Gamma Function Disable */                                       \
    ILI9341_CMD(0x26, 0x01);                 /* Gamma curve selected */                                          \
    ILI9341_CMD(0xE0, 0x0F, 0x31, 0x2B, 0x0C, 0x0E, 0x08, 0x4E, 0xF1, 0x37, 0x07, 0x10, 0x03, 0x0E, 0x09, 0x00); \
    ILI9341_CMD(0xE1, 0x00, 0x0E, 0x14, 0x03, 0x11, 0x07, 0x31, 0xC1, 0x48, 0x08, 0x0F, 0x0C, 0x31, 0x36, 0x0F);

// Input (all buttons: GPIO to GND, active-low; see PINOUT.md)
#define RG_GAMEPAD_GPIO_MAP {\
    {RG_KEY_UP,     .num = GPIO_NUM_38, .pullup = 1, .level = 0},\
    {RG_KEY_DOWN,   .num = GPIO_NUM_39, .pullup = 1, .level = 0},\
    {RG_KEY_LEFT,   .num = GPIO_NUM_40, .pullup = 1, .level = 0},\
    {RG_KEY_RIGHT,  .num = GPIO_NUM_41, .pullup = 1, .level = 0},\
    {RG_KEY_A,      .num = GPIO_NUM_47, .pullup = 1, .level = 0},\
    {RG_KEY_B,      .num = GPIO_NUM_48, .pullup = 1, .level = 0},\
    {RG_KEY_START,  .num = GPIO_NUM_13, .pullup = 1, .level = 0},\
    {RG_KEY_SELECT, .num = GPIO_NUM_14, .pullup = 1, .level = 0},\
    {RG_KEY_MENU,   .num = GPIO_NUM_12, .pullup = 1, .level = 0},\
    {RG_KEY_OPTION, .num = GPIO_NUM_0,  .pullup = 0, .level = 0},\
}
// OPTION is the BOOT button on the back of the console (external 10k pull-up
// fitted, hence .pullup = 0) - same arrangement as the ODROID-GO.

// Battery (ADC1 channel 0 = GPIO1, 100k/100k divider = x2, same maths as
// the ODROID-GO target)
#define RG_BATTERY_DRIVER           1
#define RG_BATTERY_ADC_UNIT         ADC_UNIT_1
#define RG_BATTERY_ADC_CHANNEL      ADC_CHANNEL_0
#define RG_BATTERY_CALC_PERCENT(raw) (((raw) * 2.f - 3500.f) / (4200.f - 3500.f) * 100.f)
#define RG_BATTERY_CALC_VOLTAGE(raw) ((raw) * 2.f * 0.001f)

// Status LED (red, front edge)
#define RG_GPIO_LED                 GPIO_NUM_2

// SPI Display
#define RG_GPIO_LCD_MISO            GPIO_NUM_17
#define RG_GPIO_LCD_MOSI            GPIO_NUM_8
#define RG_GPIO_LCD_CLK             GPIO_NUM_18
#define RG_GPIO_LCD_CS              GPIO_NUM_16
#define RG_GPIO_LCD_DC              GPIO_NUM_15
#define RG_GPIO_LCD_BCKL            GPIO_NUM_6
#define RG_GPIO_LCD_RST             GPIO_NUM_7

// SPI SD Card (same bus as the LCD; CS is pin 14 of the screen module)
#define RG_GPIO_SDSPI_MISO          GPIO_NUM_17
#define RG_GPIO_SDSPI_MOSI          GPIO_NUM_8
#define RG_GPIO_SDSPI_CLK           GPIO_NUM_18
#define RG_GPIO_SDSPI_CS            GPIO_NUM_5

// External I2S DAC (MAX98357A; its SD_MODE pin is resistor-set to (L+R)/2
// mono mix and the amp is always on with VSYS, so no amp-enable GPIO)
#define RG_GPIO_SND_I2S_BCK         GPIO_NUM_4
// 2026-11-08: WS/DATA swapped vs the original freeze (PCB routing fix —
// the swap removes a forced track crossing at the module; see PINOUT.md).
#define RG_GPIO_SND_I2S_WS          GPIO_NUM_10
#define RG_GPIO_SND_I2S_DATA        GPIO_NUM_9
// #define RG_GPIO_SND_AMP_ENABLE      GPIO_NUM_NC

// Updater
#define RG_UPDATER_ENABLE               1
#define RG_UPDATER_APPLICATION          RG_APP_FACTORY
#define RG_UPDATER_DOWNLOAD_LOCATION    RG_STORAGE_ROOT "/rafay-console/firmware"
