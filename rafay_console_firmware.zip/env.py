# This file is injected late into rg_tool.py (see retro-go PORTING.md)

# Espressif chip in the device
IDF_TARGET = "esp32s3"

# No FW_FORMAT: this device is flashed with the .img image over USB
# (see ../FLASHING.md), not with an ODROID-style .fw file.

# Default apps to build when none is specified (comment to build all)
# DEFAULT_APPS = "launcher retro-core gb-go nes-go"
