# FLASHING.md — Retro-Go on the Rafay Console (Rev 1)

**Build status: COMPILE-VERIFIED 2026-11-08.** Built end-to-end with
ESP-IDF **v5.2.2** and Retro-Go master (1.46-8-g4ced1): the launcher and
all apps (launcher, retro-core, prboom-go, gwenesis, fmsx) compile and
link, and `build-img` packed the flashable image
`retro-go_1.46-8-g4ced1-dirty_rafay-console.img` (**5,374,208 bytes** —
the `-dirty` suffix just marks the step-2 edit below; harmless). Two
first-build fixes were needed and are now documented in this file: the
target registration in step 2 (without it the build silently falls back
to the ODROID-GO config and fails on ESP32-S3), and the partition-table
lines that are now included in the target's `sdkconfig`. NOT yet run on
real hardware — the screen-rotation byte (step 6) remains the expected
one-line bring-up tweak. Full build log: `../work/FW_BUILD_STATUS.md`.

## 1. Toolchain

- Install **ESP-IDF v5.2.2** (the version this target was verified with;
  Retro-Go supports ESP-IDF 4.4–5.3, and the ESP32-S3 + octal-PSRAM
  configuration is smoothest on 5.x).
  Follow Espressif's official get-started for your OS, choose target
  `esp32s3` during install.
- Optional but recommended (Retro-Go BUILDING.md): apply the patches in
  retro-go's `tools/patches` to the ESP-IDF install (`panic-hook` is
  optional; `sdcard-fix` was written for the ODROID-GO — harmless to
  apply, skip it if it does not apply cleanly on 5.x).

## 2. Get Retro-Go and add this target

```
git clone -b master https://github.com/ducalex/retro-go
cp -r <this package>/firmware/rafay-console  retro-go/components/retro-go/targets/
```

The folder must end up at `components/retro-go/targets/rafay-console`
containing `config.h`, `env.py`, `sdkconfig`.

**Then register the target** (Retro-Go PORTING.md requires this for every
new target; without it the build silently defaults to ODROID-GO and fails).
In `components/retro-go/config.h`, add this branch anywhere in the
`#elif` chain before the final `#else`:

```c
#elif defined(RG_TARGET_RAFAY_CONSOLE)
#include "targets/rafay-console/config.h"
```

## 3. First build (generates the full sdkconfig)

```
cd retro-go
./rg_tool.py clean
./rg_tool.py --target=rafay-console build launcher
```

The shipped `sdkconfig` is a minimal fragment and is sufficient as-is —
it already includes the partition-table lines
(`CONFIG_PARTITION_TABLE_CUSTOM=y`, filename `../partitions.csv`) that
the first compile test found necessary; without them ESP-IDF uses a 1MB
default factory partition and the 1.26MB launcher overflows it. If you
still need to adjust a setting: `cd launcher && idf.py menuconfig`, save,
then copy `launcher/sdkconfig` back over the target's `sdkconfig` (this
is Retro-Go's documented flow).

## 4. Build the full image and flash it

```
./rg_tool.py --target=rafay-console build-img
```

Verified 2026-11-08: this produced
`retro-go_1.46-8-g4ced1-dirty_rafay-console.img` (5,374,208 bytes) in the
retro-go root, from launcher.bin 1,260,752 B, retro-core.bin 1,098,256 B,
prboom-go.bin 952,992 B, gwenesis.bin 1,098,320 B, fmsx.bin 767,312 B.
(Your version string will differ with the Retro-Go commit you clone.)

Connect the console by USB-C, power switch ON, then:

```
./rg_tool.py --target=rafay-console --port=<PORT> install
```

or with esptool directly:

```
esptool.py --chip esp32s3 --port <PORT> write_flash --flash_size detect 0x0 retro-go_*.img
```

`<PORT>` is the S3's native-USB serial port (COMx on Windows, /dev/ttyACMx
on Linux). No USB-UART chip is fitted — the port appears only when the S3
is running or in download mode.

**Entering download mode on this console:** BOOT and RESET are the two
tact buttons on the BACK of the PCB (labelled on the silkscreen). Hold
BOOT, tap RESET, release BOOT. Do this with the bottom shell off, or hold
BOOT while plugging in the USB cable with the shell open. After the first
successful flash, later updates can also be installed from the SD card
via the launcher's updater (`/rafay-console/firmware` on the card).

## 5. microSD card layout

Format the card **FAT32**. Create:

```
/roms/nes/     <- .nes files   (Mario 1/2/3, ...)
/roms/gb/      <- .gb files    (Mario Land 1/2, Pokemon Red/Blue/Yellow)
/roms/gbc/     <- .gbc files   (Pokemon Gold/Silver/Crystal)
/roms/sms/  /roms/gg/  /roms/col/  /roms/pce/  /roms/lynx/  /roms/gw/
```

Retro-Go creates its own system/save folders on first boot. Use ROM files
you own. Insert the card through the slot in the console's right side —
it slides into the screen module's back-side slot (see the shell notes in
the package README). **Before first power-up, re-read verify-before-fab
item #1 in the README** (the module's pin 14 must be the SD_CS variant).

## 6. First-boot bring-up checklist

1. Screen lights, launcher readable. If rotated/mirrored: change the
   MADCTL byte (0x36) in `config.h` — try 0xE8 / 0x28 / 0x68 — rebuild,
   reflash. (Expected one-time tweak; the shipped value 0xA8 is the
   ODROID-GO reference.)
2. All 10 front buttons respond in a game (D-pad, A, B, START, SELECT,
   MENU opens the Retro-Go menu). BOOT button acts as OPTION.
3. Sound from the speaker, volume keys work in the menu. If far too loud
   or quiet, the amp gain is set by one resistor on the PCB (R_GAIN is a
   hard tie to GND = 12 dB; see PINOUT.md §6 for the gain table).
4. Battery icon moves between full and empty across a charge cycle;
   red CHG LED on while charging, green FULL LED when done.
5. SD card shows the ROM list. If the card is never detected but the
   screen works, suspect verify item #1 (module variant) first.

## 7. Day-to-day development

```
./rg_tool.py --target=rafay-console --port=<PORT> run launcher   # build+flash+monitor one app
./rg_tool.py --target=rafay-console --port=<PORT> monitor retro-core
```

Crash logs land in `/sd/crash.log` when the panic-hook patch is applied.
